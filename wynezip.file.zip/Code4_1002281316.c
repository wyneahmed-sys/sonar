// Ahmed Wyne
// 1002281316
// Coding Assignment 4

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "DrawTool.h"

int main(void) {
    // Declare the map using the constant from DrawTool.h
    char map[MAXMAPSIZE][MAXMAPSIZE];
    int mapSize;
    
    char inputBuffer[100];
    char *token1, *token2, *token3, *token4, *token5;
    
    int row, col, spots;
    char mark;
    char command = 'A'; // Start with a dummy char so the while loop runs
    
    // Pass the address of mapSize directly
    InitializeMap(map, &mapSize);
    PrintInstructions();
    PrintMap(map, mapSize);
    
    // First prompt before the loop
    printf("\nEnter draw command: ");
    fgets(inputBuffer, sizeof(inputBuffer), stdin);
    
    // Exactly 5 calls to strtok
    token1 = strtok(inputBuffer, "(),");
    token2 = strtok(NULL, "(),");
    token3 = strtok(NULL, "(),");
    token4 = strtok(NULL, "(),");
    token5 = strtok(NULL, "(),");
    
    // Grab the command letter and make it uppercase
    if (token1 != NULL) {
        int i = 0;
        while (token1[i] == ' ' || token1[i] == '\t') {
            i++;
        }
        command = toupper(token1[i]);
    } else {
        command = ' '; 
    }
    
    // Loop strictly checks for capital Q
    while (command != 'Q') {
        
        if (command == 'P' || command == 'H' || command == 'V') {
            
            // Make sure we actually got the numbers
            if (token2 != NULL && token3 != NULL && token4 != NULL) {
                row = atoi(token2);
                col = atoi(token3);
                spots = atoi(token4);
                
                // Handle the missing mark character
                if (token5 != NULL) {
                    if (token5[0] == '\n') {
                        mark = 'X'; // Default mark if they just hit enter
                    } else {
                        // Find the actual character ignoring spaces
                        int j = 0;
                        while (token5[j] == ' ' || token5[j] == '\t') {
                            j++;
                        }
                        if (token5[j] == '\n' || token5[j] == '\0') {
                            mark = 'X';
                        } else {
                            mark = token5[j];
                        }
                    }
                } else {
                    mark = 'X';
                }
                
                // Validate the coordinates
                int outOfBounds = 0;
                
                if (row < 0 || row >= mapSize || col < 0 || col >= mapSize) {
                    outOfBounds = 1;
                } else {
                    // Check if drawing the line goes off the map
                    if (command == 'H' && (col + spots > mapSize)) {
                        outOfBounds = 1;
                    } else if (command == 'V' && (row + spots > mapSize)) {
                        outOfBounds = 1;
                    }
                }
                
                // Print the exact error or draw it
                if (outOfBounds == 1) {
                    printf("That draw command is out of range\n");
                } else {
                    if (command == 'P') {
                        map[row][col] = mark; 
                    } else {
                        DrawLine(map, row, col, command, spots, mark);
                    }
                }
            } else {
                // If the formatting was totally missing the numbers
                printf("That draw command is unknown\n");
            }
            
        } else {
            // They entered an invalid letter
            printf("That draw command is unknown\n");
        }
        
        // Print map after every command
        PrintMap(map, mapSize);
        
        // Get the next command
        printf("\nEnter draw command: ");
        fgets(inputBuffer, sizeof(inputBuffer), stdin);
        
        token1 = strtok(inputBuffer, "(),");
        token2 = strtok(NULL, "(),");
        token3 = strtok(NULL, "(),");
        token4 = strtok(NULL, "(),");
        token5 = strtok(NULL, "(),");
        
        if (token1 != NULL) {
            int i = 0;
            while (token1[i] == ' ' || token1[i] == '\t') {
                i++;
            }
            command = toupper(token1[i]);
        } else {
            command = ' '; 
        }
    }

    return 0;
}